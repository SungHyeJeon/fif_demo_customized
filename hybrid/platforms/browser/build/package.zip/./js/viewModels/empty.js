define([], function() {
    function EmptyViewModel() {
        var self = this;
    };

    return new EmptyViewModel();
});